// SettingsScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const SettingsScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text>Configuraciones</Text>
      {/* Aquí puedes agregar elementos de configuración o ajustes según tus necesidades */}
      <Button title="Volver a la Página Principal" onPress={() => navigation.navigate('Home')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default SettingsScreen;
