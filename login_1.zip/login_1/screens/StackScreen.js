// StackScreen.js
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { LoginScreen, HomeScreen, SettingsScreen } from '../Navigation';

const Stack = createStackNavigator();

const StackScreen = () => {
  return (
    <Stack.Navigator initialRouteName="Login">
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
    </Stack.Navigator>
  );
};

export default StackScreen;

