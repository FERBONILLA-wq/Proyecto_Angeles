
import React from 'react';
import {NavigationContainer } from '@react-navigation/material-bottom-tabs';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import StackScreen from './screens/StackScreen';
import HomeScreen from './screens/HomeScreen';
import SettingsScreen from './screens/SettingsScreen';

const Tab = createBottomTabNavigator();
function MyTabs() {
return(
    <Tab.Navigator
        initialRouteName="Home"
        ScreenOptions={{
            tabBarActiveTintColor: 'purple'
         }}

        >

        <Tab.Screen
         name="Home" 
         component={HomeScreen}
         options={{
            tabBarLabel:'Feed',

         }}
         />
        <Tab.Screen 
        name="Settings" 
        component={SettingsScreen} />

    </Tab.Navigator>
);
}

const Navigation = () => {
  return (
    <NavigationContainer>
      <StackScreen />
    </NavigationContainer>
  );
};

export default Navigation;
